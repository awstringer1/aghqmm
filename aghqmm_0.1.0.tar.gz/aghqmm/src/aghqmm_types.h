#include <RcppEigen.h>
/** Typedefs **/
typedef Eigen::MatrixXd Mat;
typedef Eigen::VectorXd Vec;
typedef double Scalar;
