# Binary Mixed Models via Adaptive Gaussian Quadrature with Exact Gradient Computation

This is the `R` package for the submitted paper _Approximate Marginal Likelihood Inference in Mixed Models for Grouped Data_.
This README will be updated with details about the paper and/or any preprint when available.
